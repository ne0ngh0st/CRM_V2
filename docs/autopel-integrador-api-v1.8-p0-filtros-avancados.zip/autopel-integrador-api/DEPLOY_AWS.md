# Deploy AWS — Autopel Integrador API

## Opção recomendada: AWS App Runner

1. Criar repositório ECR.
2. Fazer build e push da imagem Docker.
3. Criar serviço App Runner a partir da imagem ECR.
4. Configurar VPC Connector com acesso ao Security Group dos RDS.
5. Configurar variáveis de ambiente ou Secrets Manager:
   - API_TOKEN
   - PG_HOST, PG_PORT, PG_DATABASE, PG_USER, PG_PASSWORD
   - MYSQL_HOST, MYSQL_PORT, MYSQL_DATABASE, MYSQL_USER, MYSQL_PASSWORD
6. Testar:
   - `GET https://<url>/health`
   - `GET https://<url>/metadata/connections` com Bearer Token

## Segurança mínima no RDS

Criar usuários separados e somente leitura.

### PostgreSQL

```sql
create user lovable_ro with password 'senha_forte';
grant connect on database erp to lovable_ro;
grant usage on schema public to lovable_ro;
grant select on all tables in schema public to lovable_ro;
alter default privileges in schema public grant select on tables to lovable_ro;
```

### MySQL

```sql
create user 'lovable_ro'@'%' identified by 'senha_forte';
grant select on wms.* to 'lovable_ro'@'%';
flush privileges;
```

## Teste via curl

```bash
curl https://<api-url>/health
curl -H "Authorization: Bearer $API_TOKEN" https://<api-url>/metadata/tables
```


## Ajuste de escopo — 1 PostgreSQL + 3 MySQL

Esta API deve ser implantada considerando quatro conexões externas:

1. PostgreSQL RDS
2. MySQL RDS #1
3. MySQL RDS #2
4. MySQL RDS #3

A configuração recomendada é por `CONNECTIONS_JSON`, armazenada como secret ou variável de ambiente do serviço.

Exemplo de IDs esperados:

```text
erp_pg
mysql_erp
mysql_wms
mysql_portal
```

Cada banco deve possuir usuário próprio ou usuário equivalente com permissão exclusivamente `SELECT`.

Nenhuma credencial deve ser configurada no Lovable. O Lovable receberá apenas:

```text
INTEGRADORA_API_URL
INTEGRADORA_API_TOKEN
```

A API retornará todas as conexões no endpoint:

```http
GET /metadata/connections
```

E as tabelas de todos os bancos em:

```http
GET /metadata/tables
```

## Atualização para v1.3.0

Esta versão adiciona endpoints operacionais em `/operacional/*`.

### Procedimento de atualização

1. Substituir o pacote/código anterior por esta versão.
2. Recriar a imagem Docker.
3. Publicar a nova imagem no ECR.
4. Atualizar o serviço App Runner/ECS para a nova imagem.
5. Manter as variáveis atuais de conexão e token.
6. Adicionar, se necessário, as variáveis operacionais abaixo.

```env
OPERACIONAL_CONNECTION_ID=sac
OPERACIONAL_SCHEMA=sacautopel
OPERACIONAL_PEDIDOS_VIEW=ConsultaBasePedidos
OPERACIONAL_ITENS_VIEW=ConsultaBaseNotasItens
OPERACIONAL_DEFAULT_DATE_FIELD=previsao_entrega
OPERACIONAL_DEFAULT_LIMIT=100
OPERACIONAL_MAX_LIMIT=100
```

### Validações após deploy

```bash
curl https://api-integrador.autopel.com/health
```

```bash
curl -H "Authorization: Bearer $API_TOKEN" \
  "https://api-integrador.autopel.com/operacional/pedidos?data_inicio=2026-06-01&data_fim=2026-06-15"
```

```bash
curl -H "Authorization: Bearer $API_TOKEN" \
  "https://api-integrador.autopel.com/operacional/pedidos/946745"
```

```bash
curl -H "Authorization: Bearer $API_TOKEN" \
  "https://api-integrador.autopel.com/operacional/pedidos/946745/itens"
```

### Swagger

Após o deploy, acessar:

```text
https://api-integrador.autopel.com/docs
```

Devem aparecer os novos endpoints:

- `GET /operacional/pedidos`
- `GET /operacional/pedidos/{pedido}`
- `GET /operacional/pedidos/{pedido}/itens`
- `GET /operacional/pedidos/{pedido}/timeline`
