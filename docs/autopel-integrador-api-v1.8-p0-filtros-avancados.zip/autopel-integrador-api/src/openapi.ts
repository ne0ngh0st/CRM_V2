export const openApiSpec = {
  openapi: '3.0.0',
  info: { title: 'Autopel Integrador API', version: '1.8.0' },
  security: [{ bearerAuth: [] }],
  components: {
    securitySchemes: { bearerAuth: { type: 'http', scheme: 'bearer' } },
    schemas: {
      Error: { type: 'object', properties: { error: { type: 'string' }, code: { type: 'string' } } }
    }
  },
  paths: {
    '/health': { get: { summary: 'Health check', security: [], responses: { '200': { description: 'OK' }, '503': { description: 'Degraded' } } } },
    '/metadata/connections': { get: { summary: 'Lista conexões configuradas', responses: { '200': { description: 'OK' } } } },
    '/metadata/tables': { get: { summary: 'Lista tabelas/views', responses: { '200': { description: 'OK' } } } },
    '/metadata/tables/{id}/columns': { get: { summary: 'Lista colunas de uma tabela', parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }], responses: { '200': { description: 'OK' } } } },
    '/metadata/relationships': { get: { summary: 'Lista relacionamentos FK', responses: { '200': { description: 'OK' } } } },
    '/sample/{connection}/{schema}/{table}': { get: { summary: 'Amostra limitada a 10 linhas', parameters: [{ name: 'connection', in: 'path', required: true, schema: { type: 'string' } }, { name: 'schema', in: 'path', required: true, schema: { type: 'string' } }, { name: 'table', in: 'path', required: true, schema: { type: 'string' } }, { name: 'limit', in: 'query', required: false, schema: { type: 'integer', maximum: 10 } }], responses: { '200': { description: 'OK' } } } },
    '/operacional/metadata/campos-data': { get: { summary: 'Lista campos de data permitidos para consulta operacional', responses: { '200': { description: 'OK' } } } },

    '/operacional/busca': {
      get: {
        summary: 'Busca operacional genérica por fonte/campo indicado pelo cliente',
        description: 'Consulta somente leitura em banco/schema/tabela informados. O cliente deve indicar exatamente connection/banco, schema, table/tabela, campo e valor. Se houver data, deve informar campo_data + data_inicio + data_fim. Todos os campos são validados contra metadados antes de montar SQL.',
        parameters: [
          { name: 'connection', in: 'query', required: true, description: 'ID da conexão, ex.: sac, b2b, easy', schema: { type: 'string' } },
          { name: 'schema', in: 'query', required: true, schema: { type: 'string' } },
          { name: 'table', in: 'query', required: true, description: 'Tabela ou view', schema: { type: 'string' } },
          { name: 'campo', in: 'query', required: false, description: 'Campo onde a busca será feita', schema: { type: 'string' } },
          { name: 'valor', in: 'query', required: false, description: 'Valor a buscar', schema: { type: 'string' } },
          { name: 'operador', in: 'query', required: false, description: 'eq, like ou prefix', schema: { type: 'string', enum: ['eq','like','prefix'], default: 'eq' } },
          { name: 'campo_data', in: 'query', required: false, description: 'Obrigatório quando data_inicio/data_fim forem enviados', schema: { type: 'string' } },
          { name: 'data_inicio', in: 'query', required: false, schema: { type: 'string', format: 'date' } },
          { name: 'data_fim', in: 'query', required: false, schema: { type: 'string', format: 'date' } },
          { name: 'fields', in: 'query', required: false, description: 'Lista opcional de campos para retornar, separados por vírgula', schema: { type: 'string' } },
          { name: 'order_by', in: 'query', required: false, schema: { type: 'string' } },
          { name: 'order_dir', in: 'query', required: false, schema: { type: 'string', enum: ['asc','desc'] } },
          { name: 'pagina', in: 'query', required: false, schema: { type: 'integer', default: 1 } },
          { name: 'limite', in: 'query', required: false, schema: { type: 'integer', maximum: 100, default: 50 } }
        ],
        responses: { '200': { description: 'OK' }, '400': { description: 'Parâmetros inválidos' }, '404': { description: 'Fonte não encontrada' } }
      }
    },
    '/operacional/consulta': {
      get: {
        summary: 'Consulta parametrizada com múltiplas linhas e campos selecionáveis',
        description: 'Consulta somente leitura. v1.8 adiciona in até 1000 valores, in_tuple para chaves compostas, between, ilike, is_null, not_null e not_in. campo_data é semântico: aceita colunas date/timestamp e também varchar/text com datas nos formatos YYYY-MM-DD, DD/MM/YYYY e YYYYMMDD.',
        parameters: [
          { name: 'connection', in: 'query', required: true, schema: { type: 'string' } },
          { name: 'schema', in: 'query', required: true, schema: { type: 'string' } },
          { name: 'table', in: 'query', required: true, schema: { type: 'string' } },
          { name: 'campo_data', in: 'query', required: false, description: 'Obrigatório se usar data_inicio/data_fim', schema: { type: 'string' } },
          { name: 'data_inicio', in: 'query', required: false, schema: { type: 'string', format: 'date' } },
          { name: 'data_fim', in: 'query', required: false, schema: { type: 'string', format: 'date' } },
          { name: 'campos', in: 'query', required: false, description: 'Campos a retornar, separados por vírgula', schema: { type: 'string' } },
          { name: 'campo', in: 'query', required: false, description: 'Filtro simples opcional', schema: { type: 'string' } },
          { name: 'valor', in: 'query', required: false, schema: { type: 'string' } },
          { name: 'operador', in: 'query', required: false, schema: { type: 'string', enum: ['eq','ne','gt','gte','lt','lte','like','ilike','prefix','in','not_in','in_tuple','between','is_null','not_null'] } },
          { name: 'filters', in: 'query', required: false, description: 'JSON array de filtros', schema: { type: 'string' } },
          { name: 'order_by', in: 'query', required: false, schema: { type: 'string' } },
          { name: 'order_dir', in: 'query', required: false, schema: { type: 'string', enum: ['asc','desc'] } },
          { name: 'pagina', in: 'query', required: false, schema: { type: 'integer', default: 1 } },
          { name: 'limite', in: 'query', required: false, schema: { type: 'integer', default: 100 } }
        ],
        responses: { '200': { description: 'OK' }, '400': { description: 'Parâmetros inválidos' }, '404': { description: 'Fonte não encontrada' } }
      },
      post: {
        summary: 'Consulta parametrizada via JSON',
        description: 'Mesmo comportamento do GET /operacional/consulta, aceitando campos e filtros como arrays JSON.',
        responses: { '200': { description: 'OK' }, '400': { description: 'Parâmetros inválidos' } }
      }
    },
    '/operacional/pedidos': {
      get: {
        summary: 'Consulta operacional de pedidos SAC',
        description: 'Consulta somente leitura otimizada na view sacautopel.ConsultaBasePedidos. A consulta sem data é permitida, sempre paginada. Se data_inicio/data_fim forem enviados, campo_data passa a ser obrigatório. Não executa count(*) por padrão; use include_total=true apenas quando necessário.',
        parameters: [
          { name: 'data_inicio', in: 'query', required: false, schema: { type: 'string', format: 'date' } },
          { name: 'data_fim', in: 'query', required: false, schema: { type: 'string', format: 'date' } },
          { name: 'campo_data', in: 'query', required: false, description: 'Obrigatório quando data_inicio/data_fim forem enviados', schema: { type: 'string', enum: ['previsao_entrega','data_bip','data_embarque','criado_em','atualizado_em','dt_emissao','emissao_nfe','data_entrega_desejada','previsao_faturamento'] } },
          { name: 'pedido', in: 'query', required: false, schema: { type: 'string' } },
          { name: 'pedido_cliente', in: 'query', required: false, schema: { type: 'string' } },
          { name: 'nota_fiscal', in: 'query', required: false, schema: { type: 'string' } },
          { name: 'cliente', in: 'query', required: false, schema: { type: 'string' } },
          { name: 'cnpj', in: 'query', required: false, schema: { type: 'string' } },
          { name: 'status', in: 'query', required: false, schema: { type: 'string' } },
          { name: 'transportadora', in: 'query', required: false, schema: { type: 'string' } },
          { name: 'pagina', in: 'query', required: false, schema: { type: 'integer', default: 1 } },
          { name: 'limite', in: 'query', required: false, schema: { type: 'integer', maximum: 100, default: 50 } },
          { name: 'include_total', in: 'query', required: false, description: 'Executa count(*) apenas se true. Padrão false para evitar timeout.', schema: { type: 'boolean', default: false } },
          { name: 'fuzzy', in: 'query', required: false, description: 'Usa LIKE em campos de código quando true. Padrão false para favorecer índices.', schema: { type: 'boolean', default: false } }
        ],
        responses: { '200': { description: 'OK' }, '400': { description: 'Parâmetros inválidos' }, '401': { description: 'Token inválido' } }
      }
    },
    '/operacional/pedidos/{pedido}': {
      get: {
        summary: 'Detalhe operacional do pedido',
        parameters: [
          { name: 'pedido', in: 'path', required: true, schema: { type: 'string' } },
          { name: 'data_inicio', in: 'query', required: false, schema: { type: 'string', format: 'date' } },
          { name: 'data_fim', in: 'query', required: false, schema: { type: 'string', format: 'date' } }
        ],
        responses: { '200': { description: 'OK' } }
      }
    },
    '/operacional/pedidos/{pedido}/itens': {
      get: {
        summary: 'Itens do pedido',
        parameters: [
          { name: 'pedido', in: 'path', required: true, schema: { type: 'string' } },
          { name: 'nota_fiscal', in: 'query', required: false, schema: { type: 'string' } },
          { name: 'filial', in: 'query', required: false, schema: { type: 'string' } },
          { name: 'limite', in: 'query', required: false, schema: { type: 'integer', maximum: 500 } }
        ],
        responses: { '200': { description: 'OK' } }
      }
    },
    '/operacional/pedidos/{pedido}/timeline': {
      get: {
        summary: 'Timeline operacional do pedido',
        parameters: [{ name: 'pedido', in: 'path', required: true, schema: { type: 'string' } }],
        responses: { '200': { description: 'OK' } }
      }
    }
  }
};
