import { ConnectionConfig, connections, getConnection, appConfig } from '../config';
import { getPgPool, getMysqlPool } from './db';
import { ApiError } from '../utils/errors';

export interface TableMeta {
  id: string;
  connection_id: string;
  schema: string;
  table_name: string;
  table_type: 'table' | 'view';
  total_columns: number;
}

function quotePg(id: string): string { return '"' + id.replace(/"/g, '""') + '"'; }
function quoteMysql(id: string): string { return '`' + id.replace(/`/g, '``') + '`'; }

export async function listTablesFor(c: ConnectionConfig): Promise<TableMeta[]> {
  if (c.type === 'postgres') {
    const sql = `
      select c.table_schema as schema, c.table_name,
             case when t.table_type = 'VIEW' then 'view' else 'table' end as table_type,
             count(*)::int as total_columns
      from information_schema.columns c
      join information_schema.tables t on t.table_schema = c.table_schema and t.table_name = c.table_name
      where c.table_schema not in ('information_schema','pg_catalog')
      group by c.table_schema, c.table_name, t.table_type
      order by c.table_schema, c.table_name`;
    const r = await getPgPool(c).query(sql);
    return r.rows.map(row => ({ id: `${c.id}.${row.schema}.${row.table_name}`, connection_id: c.id, schema: row.schema, table_name: row.table_name, table_type: row.table_type, total_columns: row.total_columns }));
  }
  const sql = `
    select c.table_schema as \`schema\`, c.table_name,
           case when t.table_type = 'VIEW' then 'view' else 'table' end as table_type,
           count(*) as total_columns
    from information_schema.columns c
    join information_schema.tables t on t.table_schema = c.table_schema and t.table_name = c.table_name
    where c.table_schema = ?
    group by c.table_schema, c.table_name, t.table_type
    order by c.table_schema, c.table_name`;
  const [rows] = await getMysqlPool(c).query(sql, [c.database]);
  return (rows as any[]).map(row => ({ id: `${c.id}.${row.schema}.${row.TABLE_NAME || row.table_name}`, connection_id: c.id, schema: row.schema, table_name: row.table_name, table_type: row.table_type, total_columns: Number(row.total_columns) }));
}

export async function listAllTables(): Promise<TableMeta[]> {
  const all = await Promise.all(connections.map(listTablesFor));
  return all.flat();
}

export async function ensureTable(connectionId: string, schema: string, table: string): Promise<ConnectionConfig> {
  const c = getConnection(connectionId);
  if (!c) throw new ApiError(404, 'CONNECTION_NOT_FOUND', 'Conexão não encontrada');
  const tables = await listTablesFor(c);
  if (!tables.some(t => t.schema === schema && t.table_name === table)) throw new ApiError(404, 'TABLE_NOT_FOUND', 'Tabela não encontrada nos metadados');
  return c;
}

export async function listColumnsById(id: string) {
  const [connectionId, schema, ...tableParts] = id.split('.');
  const table = tableParts.join('.');
  const c = await ensureTable(connectionId, schema, table);

  if (c.type === 'postgres') {
    const sql = `
      with pk as (
        select kcu.table_schema, kcu.table_name, kcu.column_name
        from information_schema.table_constraints tc
        join information_schema.key_column_usage kcu on tc.constraint_name=kcu.constraint_name and tc.table_schema=kcu.table_schema
        where tc.constraint_type='PRIMARY KEY'
      ), fk as (
        select kcu.table_schema, kcu.table_name, kcu.column_name,
               ccu.table_schema || '.' || ccu.table_name || '.' || ccu.column_name as fk_reference
        from information_schema.table_constraints tc
        join information_schema.key_column_usage kcu on tc.constraint_name=kcu.constraint_name and tc.table_schema=kcu.table_schema
        join information_schema.constraint_column_usage ccu on ccu.constraint_name=tc.constraint_name and ccu.table_schema=tc.table_schema
        where tc.constraint_type='FOREIGN KEY'
      )
      select c.column_name, c.data_type, c.is_nullable = 'YES' as is_nullable,
             pk.column_name is not null as is_primary_key,
             fk.column_name is not null as is_foreign_key,
             fk.fk_reference, c.ordinal_position
      from information_schema.columns c
      left join pk on pk.table_schema=c.table_schema and pk.table_name=c.table_name and pk.column_name=c.column_name
      left join fk on fk.table_schema=c.table_schema and fk.table_name=c.table_name and fk.column_name=c.column_name
      where c.table_schema=$1 and c.table_name=$2
      order by c.ordinal_position`;
    const r = await getPgPool(c).query(sql, [schema, table]);
    return r.rows;
  }

  const sql = `
    select col.column_name, col.column_type as data_type, col.is_nullable = 'YES' as is_nullable,
           col.column_key = 'PRI' as is_primary_key,
           rc.referenced_table_name is not null as is_foreign_key,
           case when rc.referenced_table_name is null then null else concat(rc.referenced_table_schema,'.',rc.referenced_table_name,'.',rc.referenced_column_name) end as fk_reference,
           col.ordinal_position
    from information_schema.columns col
    left join information_schema.key_column_usage rc on rc.table_schema=col.table_schema and rc.table_name=col.table_name and rc.column_name=col.column_name and rc.referenced_table_name is not null
    where col.table_schema=? and col.table_name=?
    order by col.ordinal_position`;
  const [rows] = await getMysqlPool(c).query(sql, [schema, table]);
  return rows;
}

export async function listRelationships() {
  const result: any[] = [];
  for (const c of connections) {
    if (c.type === 'postgres') {
      const sql = `
        select kcu.table_schema as from_schema, kcu.table_name as from_table, kcu.column_name as from_column,
               ccu.table_schema as to_schema, ccu.table_name as to_table, ccu.column_name as to_column
        from information_schema.table_constraints tc
        join information_schema.key_column_usage kcu on tc.constraint_name=kcu.constraint_name and tc.table_schema=kcu.table_schema
        join information_schema.constraint_column_usage ccu on ccu.constraint_name=tc.constraint_name and ccu.table_schema=tc.table_schema
        where tc.constraint_type='FOREIGN KEY' and kcu.table_schema not in ('information_schema','pg_catalog')`;
      const r = await getPgPool(c).query(sql);
      result.push(...r.rows.map(row => ({ from: { connection_id: c.id, schema: row.from_schema, table: row.from_table, column: row.from_column }, to: { connection_id: c.id, schema: row.to_schema, table: row.to_table, column: row.to_column }, type: 'many_to_one' })));
    } else {
      const sql = `
        select table_schema as from_schema, table_name as from_table, column_name as from_column,
               referenced_table_schema as to_schema, referenced_table_name as to_table, referenced_column_name as to_column
        from information_schema.key_column_usage
        where table_schema=? and referenced_table_name is not null`;
      const [rows] = await getMysqlPool(c).query(sql, [c.database]);
      result.push(...(rows as any[]).map(row => ({ from: { connection_id: c.id, schema: row.from_schema, table: row.from_table, column: row.from_column }, to: { connection_id: c.id, schema: row.to_schema, table: row.to_table, column: row.to_column }, type: 'many_to_one' })));
    }
  }
  return result;
}

export async function sampleRows(connectionId: string, schema: string, table: string, limitRaw: number) {
  const c = await ensureTable(connectionId, schema, table);
  const limit = Math.min(Math.max(Number(limitRaw) || 10, 1), appConfig.sampleMaxLimit, 10);
  if (c.type === 'postgres') {
    const sql = `select * from ${quotePg(schema)}.${quotePg(table)} limit ${limit}`;
    const r = await getPgPool(c).query(sql);
    return { connection: connectionId, schema, table, row_count: r.rows.length, columns: r.fields.map(f => f.name), rows: r.rows.map(row => r.fields.map(f => row[f.name])) };
  }
  const sql = `select * from ${quoteMysql(schema)}.${quoteMysql(table)} limit ${limit}`;
  const [rows, fields] = await getMysqlPool(c).query(sql);
  const cols = (fields as any[]).map(f => f.name);
  return { connection: connectionId, schema, table, row_count: (rows as any[]).length, columns: cols, rows: (rows as any[]).map(row => cols.map(col => row[col])) };
}
