import { getConnection, appConfig } from '../config';
import { getPgPool, getMysqlPool } from './db';
import { ensureTable, listColumnsById } from './metadata';
import { ApiError } from '../utils/errors';

const DEFAULT_CONNECTION = process.env.OPERACIONAL_CONNECTION_ID || 'sac';
const DEFAULT_SCHEMA = process.env.OPERACIONAL_SCHEMA || 'sacautopel';
const PEDIDOS_VIEW = process.env.OPERACIONAL_PEDIDOS_VIEW || 'ConsultaBasePedidos';
const ITENS_VIEW = process.env.OPERACIONAL_ITENS_VIEW || 'ConsultaBaseNotasItens';

// v1.6: adiciona busca operacional genérica por conexão/schema/tabela/campo/valor.
// v1.5: otimiza busca operacional por pedido/NF para evitar OR amplo na view:
// - filtro pedido usa campo específico por padrão (numero), não OR em 5 colunas.
// - filtros dedicados por numero_pedido, pedido_nfe, ped_cliente, nota_fiscal.
// - campo_busca permite escolher exatamente a coluna de busca entre lista segura.
// - datas continuam opcionais; se houver data, campo_data + par data_inicio/data_fim são obrigatórios.
// - datas são opcionais; se houver data, campo_data + par data_inicio/data_fim são obrigatórios.
// - não usa date(campo), para não invalidar índice.
// - não executa count(*) por padrão.
// - não faz join na listagem.
// - select somente das colunas necessárias.
const DEFAULT_LIMIT = Math.min(Number(process.env.OPERACIONAL_DEFAULT_LIMIT || 50), 100);
const MAX_LIMIT = Math.min(Number(process.env.OPERACIONAL_MAX_LIMIT || 100), 100);
const MAX_DETAIL_LIMIT = Math.min(Number(process.env.OPERACIONAL_DETAIL_LIMIT || 20), 100);
const MAX_ITEM_LIMIT = Math.min(Number(process.env.OPERACIONAL_ITEM_LIMIT || 200), 500);
const MYSQL_QUERY_TIMEOUT_MS = Number(process.env.OPERACIONAL_QUERY_TIMEOUT_MS || process.env.QUERY_TIMEOUT_MS || 12000);

const ALLOWED_DATE_FIELDS = new Set([
  'previsao_entrega',
  'data_bip',
  'data_embarque',
  'criado_em',
  'atualizado_em',
  'dt_emissao',
  'emissao_nfe',
  'data_entrega_desejada',
  'previsao_faturamento'
]);


const ALLOWED_PEDIDO_SEARCH_FIELDS = new Set(['numero', 'pedido_nfe', 'ped_cliente', 'nota_fiscal', 'numero_nfe']);
const ALLOWED_TEXT_FILTERS: Record<string, string[]> = {
  pedido: ['numero'], // v1.5: default seguro. Use campo_busca para escolher outra coluna.
  numero_pedido: ['numero'],
  pedido_nfe: ['pedido_nfe'],
  pedido_cliente: ['ped_cliente'],
  nota_fiscal: ['nota_fiscal', 'numero_nfe'],
  cnpj: ['cnpj_cpf', 'cnpj_cpf_nfe']
};

function getPedidoSearchFields(query: any): string[] {
  const requested = str(query.campo_busca || query.campo_pedido);
  if (!requested) return ALLOWED_TEXT_FILTERS.pedido;
  if (!ALLOWED_PEDIDO_SEARCH_FIELDS.has(requested)) {
    throw new ApiError(400, 'INVALID_SEARCH_FIELD', `Campo de busca inválido: ${requested}`);
  }
  return [requested];
}

const DATE_FIELD_LABELS: Record<string, string> = {
  previsao_entrega: 'Previsão de entrega',
  data_bip: 'Data de bipagem',
  data_embarque: 'Data de embarque',
  criado_em: 'Criação do registro',
  atualizado_em: 'Última atualização',
  dt_emissao: 'Data de emissão do pedido',
  emissao_nfe: 'Data de emissão da NF',
  data_entrega_desejada: 'Data de entrega desejada',
  previsao_faturamento: 'Previsão de faturamento'
};

type SqlParam = string | number;

function quoteMysql(id: string): string { return '`' + id.replace(/`/g, '``') + '`'; }

function requireConnection() {
  const c = getConnection(DEFAULT_CONNECTION);
  if (!c) throw new ApiError(500, 'OPERACIONAL_CONNECTION_NOT_FOUND', `Conexão operacional não encontrada: ${DEFAULT_CONNECTION}`);
  if (c.type !== 'mysql') throw new ApiError(500, 'UNSUPPORTED_OPERATIONAL_DB', 'Consulta operacional SAC está configurada para MySQL');
  return c;
}

async function ensureOperationalViews() {
  await ensureTable(DEFAULT_CONNECTION, DEFAULT_SCHEMA, PEDIDOS_VIEW);
  await ensureTable(DEFAULT_CONNECTION, DEFAULT_SCHEMA, ITENS_VIEW);
}

function parseDate(value: unknown, name: string): string {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) {
    throw new ApiError(400, 'INVALID_DATE', `${name} deve estar no formato YYYY-MM-DD`);
  }
  const date = new Date(`${value}T00:00:00Z`);
  if (Number.isNaN(date.getTime())) throw new ApiError(400, 'INVALID_DATE', `${name} inválida`);
  return value;
}

function validateOptionalPeriod(query: any): { dataInicio?: string; dataFim?: string; dateField?: string; hasPeriod: boolean } {
  const hasInicio = query.data_inicio !== undefined && query.data_inicio !== null && String(query.data_inicio).trim() !== '';
  const hasFim = query.data_fim !== undefined && query.data_fim !== null && String(query.data_fim).trim() !== '';
  const hasCampo = query.campo_data !== undefined && query.campo_data !== null && String(query.campo_data).trim() !== '';

  if (!hasInicio && !hasFim && !hasCampo) return { hasPeriod: false };

  if (!hasInicio || !hasFim || !hasCampo) {
    throw new ApiError(400, 'INVALID_PERIOD', 'Ao informar data, envie campo_data, data_inicio e data_fim juntos');
  }

  const requestedField = String(query.campo_data).trim();
  if (!ALLOWED_DATE_FIELDS.has(requestedField)) {
    throw new ApiError(400, 'INVALID_DATE_FIELD', `Campo de data não permitido: ${requestedField}`);
  }

  const dataInicio = parseDate(query.data_inicio, 'data_inicio');
  const dataFim = parseDate(query.data_fim, 'data_fim');
  if (new Date(`${dataFim}T00:00:00Z`) < new Date(`${dataInicio}T00:00:00Z`)) {
    throw new ApiError(400, 'INVALID_PERIOD', 'data_fim não pode ser menor que data_inicio');
  }

  return { dataInicio, dataFim, dateField: requestedField, hasPeriod: true };
}

function str(value: unknown): string | undefined {
  if (value === undefined || value === null) return undefined;
  const s = String(value).trim();
  return s ? s : undefined;
}

function likeValue(value: unknown): string | undefined {
  const s = str(value);
  return s ? `%${s}%` : undefined;
}

function boolParam(value: unknown, fallback = false): boolean {
  if (value === undefined || value === null || value === '') return fallback;
  return ['1', 'true', 'sim', 'yes'].includes(String(value).toLowerCase());
}

function addOrExact(where: string[], params: SqlParam[], value: unknown, fields: string[]) {
  const v = str(value);
  if (!v) return;
  where.push(`(${fields.map(f => `${quoteMysql(f)} = ?`).join(' or ')})`);
  fields.forEach(() => params.push(v));
}

function addOrLike(where: string[], params: SqlParam[], value: unknown, fields: string[]) {
  const v = likeValue(value);
  if (!v) return;
  where.push(`(${fields.map(f => `${quoteMysql(f)} like ?`).join(' or ')})`);
  fields.forEach(() => params.push(v));
}

function addDateFilter(where: string[], params: SqlParam[], period: ReturnType<typeof validateOptionalPeriod>) {
  if (!period.hasPeriod || !period.dateField) return;
  // Não usar date(campo) para preservar chance de uso de índice. Para DATETIME, usa limite superior exclusivo no dia seguinte.
  where.push(`${quoteMysql(period.dateField)} >= ? and ${quoteMysql(period.dateField)} < date_add(?, interval 1 day)`);
  params.push(period.dataInicio!, period.dataFim!);
}

function pedidosProjection(): string {
  const cols = [
    'previsao_entrega','id_sac','status','id','filial','numero','cliente','loja','cliente_entrega','loja_entrega',
    'cnpj_cpf','transp','tipo_frete','ped_cliente','dt_emissao','criado_em','atualizado_em','cliente_nfe','nome_nfe',
    'emissao_nfe','pedido_nfe','estado_nfe','nome_estado_nfe','cnpj_cpf_nfe','numero_nfe','filial_nfe','serie_nfe',
    'valor_total_pedido','valor_total_servico','previsao_faturamento','data_entrega_desejada','nota_fiscal','data_bip',
    'data_embarque','motorista','transportadora','documento_devolucao'
  ];
  return cols.map(quoteMysql).join(', ');
}

function itensProjection(): string {
  const cols = [
    'dt_emissao_nfe','dt_entrega_app','dt_entrega','cliente','loja','cliente_entrega','loja_entrega','cnpj_cpf',
    'transp','tipo_frete','ped_cliente','dt_emissao','nota_fiscal_nfe','descricao_nfe','filial_nfe','item_nfe',
    'prc_unitario_nfe','produto_nfe','quantidade_nfe','serie_nfe','vlr_total_nfe','cliente_nfe','id','filial','item',
    'produto','descricao','quantidade','prc_unitario','vlr_total','qtd_entregue','entrega_clien','nota_fiscal','serie','pedido','excluido','criado_em','atualizado_em'
  ];
  return cols.map(quoteMysql).join(', ');
}

function mapPedido(row: any) {
  const filial = row.filial ?? '';
  const numero = row.numero ?? '';
  const filialNfe = row.filial_nfe ?? row.filial ?? '';
  const nf = row.nota_fiscal ?? row.numero_nfe ?? '';
  return {
    origem: 'SAC', origem_banco: DEFAULT_CONNECTION, origem_schema: DEFAULT_SCHEMA, origem_view: PEDIDOS_VIEW,
    numero_pedido: row.numero ?? null,
    pedido_cliente: row.ped_cliente ?? null,
    cliente: row.cliente ?? null,
    cliente_entrega: row.cliente_entrega ?? null,
    cnpj: row.cnpj_cpf ?? row.cnpj_cpf_nfe ?? null,
    nota_fiscal: row.nota_fiscal ?? row.numero_nfe ?? null,
    serie: row.serie_nfe ?? null,
    status: row.status ?? row.estado_nfe ?? row.nome_estado_nfe ?? null,
    valor_total: row.valor_total_pedido ?? null,
    valor_total_servico: row.valor_total_servico ?? null,
    data_pedido: row.dt_emissao ?? null,
    data_emissao_nf: row.emissao_nfe ?? null,
    previsao_entrega: row.previsao_entrega ?? null,
    data_entrega_desejada: row.data_entrega_desejada ?? null,
    data_bip: row.data_bip ?? null,
    data_embarque: row.data_embarque ?? null,
    transportadora: row.transportadora ?? row.transp ?? null,
    motorista: row.motorista ?? null,
    filial: row.filial ?? null,
    filial_nfe: row.filial_nfe ?? null,
    numero_nfe: row.numero_nfe ?? null,
    pedido_nfe: row.pedido_nfe ?? null,
    chave_pedido_sac: `${filial}|${numero}`,
    chave_nf_sac: `${filialNfe}|${nf}`,
    raw: row
  };
}

function mapItem(row: any) {
  const filial = row.filial ?? '';
  const pedido = row.pedido ?? '';
  const item = row.item ?? row.item_nfe ?? '';
  const filialNfe = row.filial_nfe ?? row.filial ?? '';
  const nf = row.nota_fiscal ?? row.nota_fiscal_nfe ?? '';
  return {
    origem: 'SAC',
    pedido: row.pedido ?? null,
    nota_fiscal: row.nota_fiscal ?? row.nota_fiscal_nfe ?? null,
    serie: row.serie ?? row.serie_nfe ?? null,
    item: row.item ?? row.item_nfe ?? null,
    produto: row.produto ?? row.produto_nfe ?? null,
    descricao: row.descricao ?? row.descricao_nfe ?? null,
    quantidade: row.quantidade ?? row.quantidade_nfe ?? null,
    preco_unitario: row.prc_unitario ?? row.prc_unitario_nfe ?? null,
    valor_total_item: row.vlr_total ?? row.vlr_total_nfe ?? null,
    qtd_entregue: row.qtd_entregue ?? null,
    filial: row.filial ?? null,
    filial_nfe: row.filial_nfe ?? null,
    chave_pedido_item_sac: `${filial}|${pedido}|${item}`,
    chave_nf_item_sac: `${filialNfe}|${nf}|${item}`,
    raw: row
  };
}

async function runWithMaxExecution<T>(pool: any, sql: string, params: any[]): Promise<T> {
  // SET_VAR funciona em MySQL 8+; se não suportar, o comentário é ignorado em versões antigas.
  const hintedSql = sql.replace(/^select/i, `select /*+ MAX_EXECUTION_TIME(${MYSQL_QUERY_TIMEOUT_MS}) */`);
  const [rows] = await pool.query(hintedSql, params);
  return rows as T;
}

const GENERIC_DEFAULT_LIMIT = Math.min(Number(process.env.OPERACIONAL_GENERIC_DEFAULT_LIMIT || 50), 100);
const GENERIC_MAX_LIMIT = Math.min(Number(process.env.OPERACIONAL_GENERIC_MAX_LIMIT || 100), 100);
const ALLOWED_GENERIC_OPERATORS = new Set(['eq', 'like', 'prefix']);

async function getValidatedColumns(connectionId: string, schema: string, table: string): Promise<Set<string>> {
  const cols = await listColumnsById(`${connectionId}.${schema}.${table}`);
  return new Set((cols as any[]).map(c => String(c.column_name || c.COLUMN_NAME || c.name || '').trim()).filter(Boolean));
}

function validateIdentifierAgainstColumns(columns: Set<string>, field: unknown, label: string): string | undefined {
  const f = str(field);
  if (!f) return undefined;
  if (!columns.has(f)) throw new ApiError(400, 'INVALID_FIELD', `${label} inválido ou inexistente na fonte: ${f}`);
  return f;
}

function validateConnectionSchemaTable(query: any) {
  const connection = str(query.connection || query.banco || query.origem_banco);
  const schema = str(query.schema);
  const table = str(query.table || query.tabela || query.view);
  if (!connection || !schema || !table) {
    throw new ApiError(400, 'MISSING_SOURCE', 'Informe connection/banco, schema e table/tabela');
  }
  return { connection, schema, table };
}

function sqlForConnectionType(c: any, schema: string, table: string, columns: string[] | null) {
  const quote = c.type === 'postgres' ? (id: string) => '"' + id.replace(/"/g, '""') + '"' : quoteMysql;
  const projection = columns && columns.length ? columns.map(quote).join(', ') : '*';
  return { quote, from: `${quote(schema)}.${quote(table)}`, projection };
}

function parseFieldsParam(raw: unknown, availableColumns: Set<string>): string[] | null {
  const f = str(raw);
  if (!f) return null;
  const fields = f.split(',').map(x => x.trim()).filter(Boolean);
  if (!fields.length) return null;
  for (const field of fields) {
    if (!availableColumns.has(field)) throw new ApiError(400, 'INVALID_FIELD', `Campo solicitado em fields inexistente: ${field}`);
  }
  return fields;
}

async function runGenericQuery(c: any, sql: string, params: any[]): Promise<any[]> {
  const hintedSql = c.type === 'mysql'
    ? sql.replace(/^select/i, `select /*+ MAX_EXECUTION_TIME(${MYSQL_QUERY_TIMEOUT_MS}) */`)
    : sql;
  if (c.type === 'postgres') {
    const pool = getPgPool(c);
    const r = await pool.query(hintedSql, params);
    return r.rows;
  }
  const pool = getMysqlPool(c);
  const [rows] = await pool.query(hintedSql, params);
  return rows as any[];
}

export async function buscaOperacionalGenerica(query: any) {
  const { connection, schema, table } = validateConnectionSchemaTable(query);
  const c = await ensureTable(connection, schema, table);
  if (c.type !== 'mysql') {
    throw new ApiError(400, 'UNSUPPORTED_OPERATIONAL_DB', 'Busca operacional genérica está habilitada para MySQL nesta versão');
  }
  const availableColumns = await getValidatedColumns(connection, schema, table);

  const campo = validateIdentifierAgainstColumns(availableColumns, query.campo || query.field, 'campo');
  const valor = str(query.valor || query.value || query.busca);
  const operador = str(query.operador || query.operator || 'eq') || 'eq';
  if (operador && !ALLOWED_GENERIC_OPERATORS.has(operador)) {
    throw new ApiError(400, 'INVALID_OPERATOR', `Operador inválido: ${operador}. Use eq, like ou prefix`);
  }

  if ((campo && !valor) || (!campo && valor)) {
    throw new ApiError(400, 'INVALID_SEARCH', 'Para busca por campo, informe campo e valor juntos');
  }

  const hasInicio = query.data_inicio !== undefined && query.data_inicio !== null && String(query.data_inicio).trim() !== '';
  const hasFim = query.data_fim !== undefined && query.data_fim !== null && String(query.data_fim).trim() !== '';
  const hasCampoData = query.campo_data !== undefined && query.campo_data !== null && String(query.campo_data).trim() !== '';
  if (hasInicio || hasFim || hasCampoData) {
    if (!hasInicio || !hasFim || !hasCampoData) {
      throw new ApiError(400, 'INVALID_PERIOD', 'Ao informar data, envie campo_data, data_inicio e data_fim juntos');
    }
  }
  const campoData = validateIdentifierAgainstColumns(availableColumns, query.campo_data, 'campo_data');
  const dataInicio = hasInicio ? parseDate(query.data_inicio, 'data_inicio') : undefined;
  const dataFim = hasFim ? parseDate(query.data_fim, 'data_fim') : undefined;
  if (dataInicio && dataFim && new Date(`${dataFim}T00:00:00Z`) < new Date(`${dataInicio}T00:00:00Z`)) {
    throw new ApiError(400, 'INVALID_PERIOD', 'data_fim não pode ser menor que data_inicio');
  }

  const page = Math.max(Number(query.pagina || 1), 1);
  const limit = Math.min(Math.max(Number(query.limite || GENERIC_DEFAULT_LIMIT), 1), GENERIC_MAX_LIMIT);
  const offset = (page - 1) * limit;
  const selectedFields = parseFieldsParam(query.fields || query.campos, availableColumns);
  const { quote, from, projection } = sqlForConnectionType(c, schema, table, selectedFields);

  const where: string[] = [];
  const params: SqlParam[] = [];
  if (campo && valor) {
    if (operador === 'like') {
      where.push(`${quote(campo)} like ?`); params.push(`%${valor}%`);
    } else if (operador === 'prefix') {
      where.push(`${quote(campo)} like ?`); params.push(`${valor}%`);
    } else {
      where.push(`${quote(campo)} = ?`); params.push(valor);
    }
  }
  if (campoData && dataInicio && dataFim) {
    // Operacional genérico v1.6 está otimizado para as conexões MySQL usadas no projeto atual (SAC/B2B/EASY).
    // PostgreSQL permanece suportado nos endpoints de metadados.
    if (c.type !== 'mysql') throw new ApiError(400, 'UNSUPPORTED_OPERATIONAL_DB', 'Busca operacional genérica com filtro de data está habilitada para MySQL nesta versão');
    where.push(`${quote(campoData)} >= ? and ${quote(campoData)} < date_add(?, interval 1 day)`);
    params.push(dataInicio, dataFim);
  }
  const whereSql = where.length ? where.join(' and ') : '1=1';
  const orderField = validateIdentifierAgainstColumns(availableColumns, query.order_by, 'order_by');
  const orderDir = String(query.order_dir || 'desc').toLowerCase() === 'asc' ? 'asc' : 'desc';
  const orderBy = orderField ? ` order by ${quote(orderField)} ${orderDir}` : '';

  const rows = await runGenericQuery(c, `select ${projection} from ${from} where ${whereSql}${orderBy} limit ? offset ?`, [...params, limit, offset]);
  return {
    fonte: `${connection}.${schema}.${table}`,
    connection,
    schema,
    table,
    campo_busca: campo || null,
    operador: campo ? operador : null,
    campo_data: campoData || null,
    data_inicio: dataInicio || null,
    data_fim: dataFim || null,
    pagina: page,
    limite: limit,
    total_retornado: rows.length,
    registros: rows
  };
}



const CONSULTA_DEFAULT_LIMIT = Math.min(Number(process.env.OPERACIONAL_CONSULTA_DEFAULT_LIMIT || 100), 1000);
const CONSULTA_MAX_LIMIT = Math.min(Number(process.env.OPERACIONAL_CONSULTA_MAX_LIMIT || 1000), 5000);
const CONSULTA_IN_MAX = Math.min(Number(process.env.OPERACIONAL_CONSULTA_IN_MAX || 1000), 5000);
const CONSULTA_IN_TUPLE_MAX = Math.min(Number(process.env.OPERACIONAL_CONSULTA_IN_TUPLE_MAX || 1000), 5000);
const ALLOWED_CONSULTA_OPERATORS = new Set(['eq', 'ne', 'gt', 'gte', 'lt', 'lte', 'like', 'ilike', 'prefix', 'in', 'not_in', 'in_tuple', 'between', 'is_null', 'not_null']);

type ConsultaFiltro = { field?: string | string[]; campo?: string | string[]; operator?: string; operador?: string; value?: any; valor?: any; values?: any[]; valores?: any[]; inicio?: any; fim?: any };

function parseSelectedFields(raw: any, availableColumns: Set<string>): string[] | null {
  if (Array.isArray(raw)) {
    const fields = raw.map(x => String(x).trim()).filter(Boolean);
    for (const field of fields) {
      if (!availableColumns.has(field)) throw new ApiError(400, 'INVALID_FIELD', `Campo solicitado inexistente: ${field}`);
    }
    return fields.length ? fields : null;
  }
  return parseFieldsParam(raw, availableColumns);
}

function parseConsultaFilters(query: any): ConsultaFiltro[] {
  if (Array.isArray(query.filters)) return query.filters as ConsultaFiltro[];
  if (typeof query.filters === 'string' && query.filters.trim()) {
    try {
      const parsed = JSON.parse(query.filters);
      if (!Array.isArray(parsed)) throw new Error('filters deve ser array');
      return parsed;
    } catch {
      throw new ApiError(400, 'INVALID_FILTERS', 'filters deve ser um JSON array válido');
    }
  }
  const campo = str(query.campo || query.field);
  const valor = str(query.valor || query.value || query.busca);
  if (campo || valor) return [{ campo, valor, operador: str(query.operador || query.operator || 'eq') }];
  return [];
}

function normalizeFieldList(raw: unknown): string[] {
  if (Array.isArray(raw)) return raw.map(x => String(x).trim()).filter(Boolean);
  const s = str(raw);
  return s ? s.split(',').map(x => x.trim()).filter(Boolean) : [];
}

function validateFieldListAgainstColumns(availableColumns: Set<string>, raw: unknown, label: string): string[] {
  const fields = normalizeFieldList(raw);
  if (!fields.length) throw new ApiError(400, 'INVALID_FIELD', `${label} sem campos`);
  for (const f of fields) {
    if (!availableColumns.has(f)) throw new ApiError(400, 'INVALID_FIELD', `${label} inválido ou inexistente na fonte: ${f}`);
  }
  return fields;
}

function normalizeValues(raw: any): any[] {
  if (Array.isArray(raw)) return raw;
  if (typeof raw === 'string') return raw.split(',').map(v => v.trim()).filter(Boolean);
  if (raw === undefined || raw === null || raw === '') return [];
  return [raw];
}

function mysqlDateExpression(quotedField: string): string {
  // v1.8: campo_data semântico. Aceita DATE/DATETIME/TIMESTAMP e também VARCHAR/TEXT
  // nos formatos YYYY-MM-DD, YYYY-MM-DD HH:mm:ss, DD/MM/YYYY e YYYYMMDD.
  return `(case
    when ${quotedField} is null or trim(cast(${quotedField} as char)) = '' then null
    when trim(cast(${quotedField} as char)) regexp '^[0-9]{4}-[0-9]{2}-[0-9]{2}' then date(${quotedField})
    when trim(cast(${quotedField} as char)) regexp '^[0-9]{2}/[0-9]{2}/[0-9]{4}' then str_to_date(left(trim(cast(${quotedField} as char)),10), '%d/%m/%Y')
    when trim(cast(${quotedField} as char)) regexp '^[0-9]{8}$' then str_to_date(trim(cast(${quotedField} as char)), '%Y%m%d')
    else null end)`;
}

function addConsultaDateFilter(where: string[], params: SqlParam[], quote: (id: string) => string, c: any, campoData: string, dataInicio: string, dataFim: string) {
  const qf = quote(campoData);
  if (c.type === 'mysql') {
    where.push(`${mysqlDateExpression(qf)} between ? and ?`);
    params.push(dataInicio, dataFim);
  } else {
    // Mantém suporte básico PostgreSQL para colunas DATE/TIMESTAMP.
    where.push(`${qf}::date between ?::date and ?::date`);
    params.push(dataInicio, dataFim);
  }
}

function addConsultaFilter(where: string[], params: SqlParam[], quote: (id: string) => string, availableColumns: Set<string>, filtro: ConsultaFiltro) {
  const rawField = filtro.field !== undefined ? filtro.field : filtro.campo;
  const op = str(filtro.operator || filtro.operador || 'eq') || 'eq';
  if (!ALLOWED_CONSULTA_OPERATORS.has(op)) throw new ApiError(400, 'INVALID_OPERATOR', `Operador inválido: ${op}`);

  if (op === 'in_tuple') {
    const fields = validateFieldListAgainstColumns(availableColumns, rawField, 'campos da chave composta');
    if (fields.length < 2) throw new ApiError(400, 'INVALID_FILTER', 'in_tuple exige dois ou mais campos');
    const tuples = filtro.values !== undefined ? filtro.values : (filtro.valores !== undefined ? filtro.valores : filtro.value ?? filtro.valor);
    if (!Array.isArray(tuples) || !tuples.length || tuples.length > CONSULTA_IN_TUPLE_MAX) {
      throw new ApiError(400, 'INVALID_FILTER', `Filtro in_tuple deve ter entre 1 e ${CONSULTA_IN_TUPLE_MAX} tuplas`);
    }
    for (const tuple of tuples) {
      if (!Array.isArray(tuple) || tuple.length !== fields.length) {
        throw new ApiError(400, 'INVALID_FILTER', `Cada tupla deve ter ${fields.length} valores`);
      }
    }
    const tupleSql = tuples.map(() => `(${fields.map(() => '?').join(',')})`).join(',');
    where.push(`(${fields.map(quote).join(',')}) in (${tupleSql})`);
    tuples.forEach((tuple: any[]) => tuple.forEach(v => params.push(String(v))));
    return;
  }

  const field = validateIdentifierAgainstColumns(availableColumns, rawField, 'campo do filtro');
  if (!field) throw new ApiError(400, 'INVALID_FILTER', 'Filtro sem campo');

  if (op === 'is_null') { where.push(`${quote(field)} is null`); return; }
  if (op === 'not_null') { where.push(`${quote(field)} is not null`); return; }

  const value = filtro.value !== undefined ? filtro.value : filtro.valor;

  if (op === 'between') {
    const vals = Array.isArray(value) ? value : [filtro.inicio, filtro.fim].filter(v => v !== undefined && v !== null && String(v).trim() !== '');
    if (vals.length !== 2) throw new ApiError(400, 'INVALID_FILTER', `Filtro between de ${field} exige dois valores`);
    where.push(`${quote(field)} between ? and ?`);
    params.push(String(vals[0]), String(vals[1]));
    return;
  }

  if (value === undefined || value === null || String(value).trim() === '') throw new ApiError(400, 'INVALID_FILTER', `Filtro ${field} sem valor`);

  if (op === 'eq') { where.push(`${quote(field)} = ?`); params.push(String(value)); return; }
  if (op === 'ne') { where.push(`${quote(field)} <> ?`); params.push(String(value)); return; }
  if (op === 'gt') { where.push(`${quote(field)} > ?`); params.push(String(value)); return; }
  if (op === 'gte') { where.push(`${quote(field)} >= ?`); params.push(String(value)); return; }
  if (op === 'lt') { where.push(`${quote(field)} < ?`); params.push(String(value)); return; }
  if (op === 'lte') { where.push(`${quote(field)} <= ?`); params.push(String(value)); return; }
  if (op === 'like') { where.push(`${quote(field)} like ?`); params.push(`%${String(value).trim()}%`); return; }
  if (op === 'ilike') { where.push(`lower(${quote(field)}) like lower(?)`); params.push(`%${String(value).trim()}%`); return; }
  if (op === 'prefix') { where.push(`${quote(field)} like ?`); params.push(`${String(value).trim()}%`); return; }
  if (op === 'in' || op === 'not_in') {
    const values = normalizeValues(value);
    if (!values.length || values.length > CONSULTA_IN_MAX) throw new ApiError(400, 'INVALID_FILTER', `Filtro ${op} de ${field} deve ter entre 1 e ${CONSULTA_IN_MAX} valores`);
    where.push(`${quote(field)} ${op === 'not_in' ? 'not in' : 'in'} (${values.map(() => '?').join(',')})`);
    values.forEach(v => params.push(String(v)));
    return;
  }
}

export async function consultaOperacionalParametrizada(query: any) {
  const { connection, schema, table } = validateConnectionSchemaTable(query);
  const c = await ensureTable(connection, schema, table);
  const availableColumns = await getValidatedColumns(connection, schema, table);

  const selectedFields = parseSelectedFields(query.fields || query.campos || query.select, availableColumns);
  const { quote, from, projection } = sqlForConnectionType(c, schema, table, selectedFields);

  const hasInicio = query.data_inicio !== undefined && query.data_inicio !== null && String(query.data_inicio).trim() !== '';
  const hasFim = query.data_fim !== undefined && query.data_fim !== null && String(query.data_fim).trim() !== '';
  const hasCampoData = query.campo_data !== undefined && query.campo_data !== null && String(query.campo_data).trim() !== '';
  if (hasInicio || hasFim || hasCampoData) {
    if (!hasInicio || !hasFim || !hasCampoData) {
      throw new ApiError(400, 'INVALID_PERIOD', 'Ao informar data, envie campo_data, data_inicio e data_fim juntos');
    }
  }

  const campoData = validateIdentifierAgainstColumns(availableColumns, query.campo_data || query.date_field, 'campo_data');
  const dataInicio = hasInicio ? parseDate(query.data_inicio, 'data_inicio') : undefined;
  const dataFim = hasFim ? parseDate(query.data_fim, 'data_fim') : undefined;
  if (dataInicio && dataFim && new Date(`${dataFim}T00:00:00Z`) < new Date(`${dataInicio}T00:00:00Z`)) {
    throw new ApiError(400, 'INVALID_PERIOD', 'data_fim não pode ser menor que data_inicio');
  }

  const where: string[] = [];
  const params: SqlParam[] = [];
  if (campoData && dataInicio && dataFim) {
    addConsultaDateFilter(where, params, quote, c, campoData, dataInicio, dataFim);
  }

  for (const filtro of parseConsultaFilters(query)) addConsultaFilter(where, params, quote, availableColumns, filtro);

  const page = Math.max(Number(query.pagina || query.page || 1), 1);
  const limit = Math.min(Math.max(Number(query.limite || query.limit || CONSULTA_DEFAULT_LIMIT), 1), CONSULTA_MAX_LIMIT);
  const offset = (page - 1) * limit;
  const orderField = validateIdentifierAgainstColumns(availableColumns, query.order_by || query.ordenar_por, 'order_by');
  const orderDir = String(query.order_dir || query.direcao || 'asc').toLowerCase() === 'desc' ? 'desc' : 'asc';
  const orderBy = orderField ? ` order by ${quote(orderField)} ${orderDir}` : '';
  const whereSql = where.length ? where.join(' and ') : '1=1';

  const rows = await runGenericQuery(c, `select ${projection} from ${from} where ${whereSql}${orderBy} limit ? offset ?`, [...params, limit, offset]);
  return {
    fonte: `${connection}.${schema}.${table}`,
    connection,
    schema,
    table,
    campos_retornados: selectedFields || 'todos',
    campo_data: campoData || null,
    data_inicio: dataInicio || null,
    data_fim: dataFim || null,
    filtros: parseConsultaFilters(query),
    pagina: page,
    limite: limit,
    total_retornado: rows.length,
    registros: rows
  };
}

export function camposDataOperacional() {
  return {
    fonte_principal: `${DEFAULT_CONNECTION}.${DEFAULT_SCHEMA}.${PEDIDOS_VIEW}`,
    regra: 'Consulta sem data é permitida. Se informar datas, envie campo_data, data_inicio e data_fim.',
    campos_data: Array.from(ALLOWED_DATE_FIELDS).map(campo => ({ campo, descricao: DATE_FIELD_LABELS[campo] || campo }))
  };
}

export async function consultarPedidos(query: any) {
  const c = requireConnection();
  await ensureOperationalViews();

  const period = validateOptionalPeriod(query);
  const page = Math.max(Number(query.pagina || 1), 1);
  const limit = Math.min(Math.max(Number(query.limite || DEFAULT_LIMIT), 1), MAX_LIMIT);
  const offset = (page - 1) * limit;
  const includeTotal = boolParam(query.include_total, false);
  const fuzzy = boolParam(query.fuzzy, false);

  const where: string[] = [];
  const params: SqlParam[] = [];
  addDateFilter(where, params, period);

  // v1.5: nunca pesquisar pedido em OR amplo por padrão. Isso causava full scan/timeout em views grandes.
  // Para buscar em outro campo, use campo_busca=pedido_nfe|ped_cliente|nota_fiscal|numero_nfe.
  const addText = fuzzy ? addOrLike : addOrExact;
  if (query.pedido !== undefined && query.pedido !== null && String(query.pedido).trim() !== '') {
    addText(where, params, query.pedido, getPedidoSearchFields(query));
  }
  addText(where, params, query.numero_pedido, ALLOWED_TEXT_FILTERS.numero_pedido);
  addText(where, params, query.pedido_nfe, ALLOWED_TEXT_FILTERS.pedido_nfe);
  addText(where, params, query.pedido_cliente, ALLOWED_TEXT_FILTERS.pedido_cliente);
  addText(where, params, query.nota_fiscal, ALLOWED_TEXT_FILTERS.nota_fiscal);
  addText(where, params, query.cnpj, ALLOWED_TEXT_FILTERS.cnpj);

  // Campos descritivos mantêm LIKE para usabilidade, mas só quando informados.
  addOrLike(where, params, query.cliente, ['cliente', 'cliente_entrega', 'cliente_nfe', 'nome_nfe']);
  addOrLike(where, params, query.status, ['status', 'estado_nfe', 'nome_estado_nfe']);
  addOrLike(where, params, query.transportadora, ['transportadora', 'transp']);

  const pool = getMysqlPool(c);
  const from = `${quoteMysql(DEFAULT_SCHEMA)}.${quoteMysql(PEDIDOS_VIEW)}`;
  const whereSql = where.length ? where.join(' and ') : '1=1';

  let total: number | null = null;
  if (includeTotal) {
    const countRows = await runWithMaxExecution<any[]>(pool, `select count(*) as total from ${from} where ${whereSql}`, params);
    total = Number(countRows[0]?.total || 0);
  }

  // Para busca exata por chave, não forçar ORDER BY em coluna diferente; algumas views materializam/sortem tudo.
  const hasExactKeyFilter = !fuzzy && (str(query.pedido) || str(query.numero_pedido) || str(query.pedido_nfe) || str(query.pedido_cliente) || str(query.nota_fiscal));
  const orderBy = hasExactKeyFilter
    ? `${quoteMysql('numero')} asc`
    : (period.hasPeriod && period.dateField
      ? `${quoteMysql(period.dateField)} desc, ${quoteMysql('numero')} desc`
      : `${quoteMysql('id')} desc`);

  const rows = await runWithMaxExecution<any[]>(
    pool,
    `select ${pedidosProjection()} from ${from} where ${whereSql} order by ${orderBy} limit ? offset ?`,
    [...params, limit, offset]
  );

  return {
    origem: 'SAC',
    fonte: `${DEFAULT_CONNECTION}.${DEFAULT_SCHEMA}.${PEDIDOS_VIEW}`,
    campo_data_utilizado: period.hasPeriod ? period.dateField : null,
    campo_busca_utilizado: str(query.pedido) ? getPedidoSearchFields(query)[0] : null,
    data_inicio: period.dataInicio ?? null,
    data_fim: period.dataFim ?? null,
    pagina: page,
    limite: limit,
    include_total: includeTotal,
    total,
    total_paginas: total === null ? null : Math.ceil(total / limit),
    registros: rows.map(mapPedido)
  };
}

export async function detalhePedido(pedido: string, query: any) {
  const c = requireConnection();
  await ensureOperationalViews();
  const pool = getMysqlPool(c);
  const from = `${quoteMysql(DEFAULT_SCHEMA)}.${quoteMysql(PEDIDOS_VIEW)}`;
  const detailField = str(query.campo_busca || query.campo_pedido);
  const detailFields = detailField ? getPedidoSearchFields({ campo_busca: detailField }) : ['numero'];
  const where: string[] = [`(${detailFields.map(f => `${quoteMysql(f)} = ?`).join(' or ')})`];
  const params: SqlParam[] = detailFields.map(() => pedido);
  addDateFilter(where, params, validateOptionalPeriod(query));

  const rows = await runWithMaxExecution<any[]>(
    pool,
    `select ${pedidosProjection()} from ${from} where ${where.join(' and ')} order by ${quoteMysql('id')} desc limit ?`,
    [...params, MAX_DETAIL_LIMIT]
  );
  return { origem: 'SAC', fonte: `${DEFAULT_CONNECTION}.${DEFAULT_SCHEMA}.${PEDIDOS_VIEW}`, busca: pedido, total: rows.length, registros: rows.map(mapPedido) };
}

export async function itensPedido(pedido: string, query: any) {
  const c = requireConnection();
  await ensureOperationalViews();
  const pool = getMysqlPool(c);
  const from = `${quoteMysql(DEFAULT_SCHEMA)}.${quoteMysql(ITENS_VIEW)}`;
  const limit = Math.min(Math.max(Number(query.limite || MAX_ITEM_LIMIT), 1), 500);

  const where: string[] = ['(`pedido` = ? or `nota_fiscal` = ? or `nota_fiscal_nfe` = ? or `ped_cliente` = ?)'];
  const params: SqlParam[] = [pedido, pedido, pedido, pedido];

  addOrExact(where, params, query.nota_fiscal, ['nota_fiscal', 'nota_fiscal_nfe']);
  addOrExact(where, params, query.filial, ['filial', 'filial_nfe']);

  const rows = await runWithMaxExecution<any[]>(
    pool,
    `select ${itensProjection()} from ${from} where ${where.join(' and ')} order by ${quoteMysql('item')} limit ?`,
    [...params, limit]
  );
  return { origem: 'SAC', fonte: `${DEFAULT_CONNECTION}.${DEFAULT_SCHEMA}.${ITENS_VIEW}`, busca: pedido, total: rows.length, registros: rows.map(mapItem) };
}

export async function timelinePedido(pedido: string, query: any) {
  const detalhe = await detalhePedido(pedido, query);
  const eventos: any[] = [];
  for (const r of detalhe.registros) {
    if (r.raw?.criado_em) eventos.push({ data: r.raw.criado_em, tipo: 'criado', descricao: 'Pedido criado', origem: 'ConsultaBasePedidos' });
    if (r.data_pedido) eventos.push({ data: r.data_pedido, tipo: 'emissao_pedido', descricao: 'Emissão do pedido', origem: 'ConsultaBasePedidos' });
    if (r.data_bip) eventos.push({ data: r.data_bip, tipo: 'bipagem', descricao: 'Bipagem registrada', origem: 'ConsultaBasePedidos' });
    if (r.data_embarque) eventos.push({ data: r.data_embarque, tipo: 'embarque', descricao: 'Embarque registrado', origem: 'ConsultaBasePedidos' });
    if (r.previsao_entrega) eventos.push({ data: r.previsao_entrega, tipo: 'previsao_entrega', descricao: 'Previsão de entrega', origem: 'ConsultaBasePedidos' });
  }
  eventos.sort((a, b) => String(a.data).localeCompare(String(b.data)));
  return { origem: 'SAC', busca: pedido, total: eventos.length, eventos };
}
