import pg from 'pg';
import mysql from 'mysql2/promise';
import { ConnectionConfig, connections, appConfig } from '../config';

const pgPools = new Map<string, pg.Pool>();
const mysqlPools = new Map<string, mysql.Pool>();

export function getPgPool(c: ConnectionConfig): pg.Pool {
  let pool = pgPools.get(c.id);
  if (!pool) {
    pool = new pg.Pool({ host: c.host, port: c.port, database: c.database, user: c.user, password: c.password, statement_timeout: appConfig.queryTimeoutMs, max: 5 });
    pgPools.set(c.id, pool);
  }
  return pool;
}

export function getMysqlPool(c: ConnectionConfig): mysql.Pool {
  let pool = mysqlPools.get(c.id);
  if (!pool) {
    pool = mysql.createPool({ host: c.host, port: c.port, database: c.database, user: c.user, password: c.password, connectionLimit: 5, connectTimeout: appConfig.queryTimeoutMs });
    mysqlPools.set(c.id, pool);
  }
  return pool;
}

export async function healthCheckConnection(c: ConnectionConfig) {
  const start = Date.now();
  if (c.type === 'postgres') await getPgPool(c).query('select 1');
  else await getMysqlPool(c).query('select 1');
  return { id: c.id, type: c.type, reachable: true, latency_ms: Date.now() - start };
}

export async function closePools() {
  await Promise.all([...pgPools.values()].map(p => p.end()));
  await Promise.all([...mysqlPools.values()].map(p => p.end()));
}

export function publicConnections() {
  return connections.map(c => ({ id: c.id, nome: c.name, tipo: c.type, host: c.host, porta: c.port, database: c.database, usuario: c.user, status: 'configured' }));
}
