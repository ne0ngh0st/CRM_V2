import { Router } from 'express';
import { publicConnections } from '../services/db';
import { listAllTables, listColumnsById, listRelationships } from '../services/metadata';

export const metadataRouter = Router();

metadataRouter.get('/metadata/connections', (_req, res) => res.json(publicConnections()));
metadataRouter.get('/metadata/tables', async (_req, res, next) => { try { res.json(await listAllTables()); } catch (e) { next(e); } });
metadataRouter.get('/metadata/tables/:id/columns', async (req, res, next) => { try { res.json(await listColumnsById(req.params.id)); } catch (e) { next(e); } });
metadataRouter.get('/metadata/relationships', async (_req, res, next) => { try { res.json(await listRelationships()); } catch (e) { next(e); } });
