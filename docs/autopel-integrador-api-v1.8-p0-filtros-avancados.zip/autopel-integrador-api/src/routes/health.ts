import { Router } from 'express';
import { appConfig, connections } from '../config';
import { healthCheckConnection } from '../services/db';

export const healthRouter = Router();

healthRouter.get('/health', async (_req, res) => {
  const checks = await Promise.all(connections.map(async c => {
    try { return await healthCheckConnection(c); }
    catch (e) { return { id: c.id, type: c.type, reachable: false, latency_ms: null, error: (e as Error).message }; }
  }));
  const ok = checks.every(c => c.reachable);
  res.status(ok ? 200 : 503).json({ status: ok ? 'ok' : 'degraded', uptime_seconds: Math.floor((Date.now() - appConfig.startedAt) / 1000), version: appConfig.version, connections: checks });
});
