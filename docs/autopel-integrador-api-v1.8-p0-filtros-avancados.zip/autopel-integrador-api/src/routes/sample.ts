import { Router } from 'express';
import { sampleRows } from '../services/metadata';

export const sampleRouter = Router();

sampleRouter.get('/sample/:connection/:schema/:table', async (req, res, next) => {
  try {
    const limit = Number(req.query.limit || 10);
    res.json(await sampleRows(req.params.connection, req.params.schema, req.params.table, limit));
  } catch (e) { next(e); }
});
