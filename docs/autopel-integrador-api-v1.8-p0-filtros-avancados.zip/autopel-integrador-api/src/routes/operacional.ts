import { Router } from 'express';
import { consultarPedidos, detalhePedido, itensPedido, timelinePedido, camposDataOperacional, buscaOperacionalGenerica, consultaOperacionalParametrizada } from '../services/operacional';

export const operacionalRouter = Router();

operacionalRouter.get('/operacional/metadata/campos-data', (_req, res) => {
  res.json(camposDataOperacional());
});


operacionalRouter.get('/operacional/busca', async (req, res, next) => {
  try { res.json(await buscaOperacionalGenerica(req.query)); } catch (e) { next(e); }
});

operacionalRouter.get('/operacional/consulta', async (req, res, next) => {
  try { res.json(await consultaOperacionalParametrizada(req.query)); } catch (e) { next(e); }
});

operacionalRouter.post('/operacional/consulta', async (req, res, next) => {
  try { res.json(await consultaOperacionalParametrizada(req.body || {})); } catch (e) { next(e); }
});

operacionalRouter.get('/operacional/pedidos', async (req, res, next) => {
  try { res.json(await consultarPedidos(req.query)); } catch (e) { next(e); }
});

operacionalRouter.get('/operacional/pedidos/:pedido', async (req, res, next) => {
  try { res.json(await detalhePedido(req.params.pedido, req.query)); } catch (e) { next(e); }
});

operacionalRouter.get('/operacional/pedidos/:pedido/itens', async (req, res, next) => {
  try { res.json(await itensPedido(req.params.pedido, req.query)); } catch (e) { next(e); }
});

operacionalRouter.get('/operacional/pedidos/:pedido/timeline', async (req, res, next) => {
  try { res.json(await timelinePedido(req.params.pedido, req.query)); } catch (e) { next(e); }
});
