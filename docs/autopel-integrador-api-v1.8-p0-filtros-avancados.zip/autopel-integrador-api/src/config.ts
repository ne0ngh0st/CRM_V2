import dotenv from 'dotenv';
dotenv.config();

export type DbType = 'postgres' | 'mysql';

export interface ConnectionConfig {
  id: string;
  name: string;
  type: DbType;
  host: string;
  port: number;
  database: string;
  user: string;
  password: string;
}

function bool(v: string | undefined): boolean { return String(v).toLowerCase() === 'true'; }
function num(v: string | undefined, fallback: number): number { const n = Number(v); return Number.isFinite(n) ? n : fallback; }
function env(name: string): string { return process.env[name] || ''; }

export const appConfig = {
  port: num(process.env.PORT, 3000),
  apiToken: process.env.API_TOKEN || '',
  allowedOrigins: (process.env.ALLOWED_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean),
  queryTimeoutMs: num(process.env.QUERY_TIMEOUT_MS, 5000),
  sampleMaxLimit: Math.min(num(process.env.SAMPLE_MAX_LIMIT, 10), 10),
  startedAt: Date.now(),
  version: process.env.npm_package_version || '1.1.0'
};

function parseConnectionsJson(): ConnectionConfig[] {
  if (!process.env.CONNECTIONS_JSON) return [];
  try {
    const parsed = JSON.parse(process.env.CONNECTIONS_JSON);
    if (!Array.isArray(parsed)) throw new Error('CONNECTIONS_JSON deve ser um array');
    return parsed.map((c) => ({
      id: String(c.id),
      name: String(c.name || c.id),
      type: (c.type === 'postgres' ? 'postgres' : 'mysql') as DbType,
      host: String(c.host),
      port: Number(c.port || (c.type === 'postgres' ? 5432 : 3306)),
      database: String(c.database),
      user: String(c.user),
      password: String(c.password)
    })).filter(c => c.id && c.host && c.database && c.user && c.password);
  } catch (err) {
    console.error('Erro ao ler CONNECTIONS_JSON:', err);
    return [];
  }
}

function legacyConnections(): ConnectionConfig[] {
  const list: ConnectionConfig[] = [];

  if (bool(process.env.PG_ENABLED)) {
    list.push({
      id: process.env.PG_ID || 'postgres_prod',
      name: process.env.PG_NAME || 'PostgreSQL Produção',
      type: 'postgres',
      host: env('PG_HOST'),
      port: num(process.env.PG_PORT, 5432),
      database: env('PG_DATABASE'),
      user: env('PG_USER'),
      password: env('PG_PASSWORD')
    });
  }

  // Suporta até 10 conexões MySQL por variáveis MYSQL_1_*, MYSQL_2_*, etc.
  for (let i = 1; i <= 10; i++) {
    const prefix = `MYSQL_${i}`;
    if (bool(process.env[`${prefix}_ENABLED`])) {
      list.push({
        id: process.env[`${prefix}_ID`] || `mysql_${i}`,
        name: process.env[`${prefix}_NAME`] || `MySQL ${i}`,
        type: 'mysql',
        host: env(`${prefix}_HOST`),
        port: num(process.env[`${prefix}_PORT`], 3306),
        database: env(`${prefix}_DATABASE`),
        user: env(`${prefix}_USER`),
        password: env(`${prefix}_PASSWORD`)
      });
    }
  }

  // Compatibilidade com a versão anterior: MYSQL_* simples.
  if (bool(process.env.MYSQL_ENABLED)) {
    list.push({
      id: process.env.MYSQL_ID || 'mysql_prod',
      name: process.env.MYSQL_NAME || 'MySQL Produção',
      type: 'mysql',
      host: env('MYSQL_HOST'),
      port: num(process.env.MYSQL_PORT, 3306),
      database: env('MYSQL_DATABASE'),
      user: env('MYSQL_USER'),
      password: env('MYSQL_PASSWORD')
    });
  }

  return list.filter(c => c.host && c.database && c.user && c.password);
}

const jsonConnections = parseConnectionsJson();
export const connections: ConnectionConfig[] = (jsonConnections.length ? jsonConnections : legacyConnections());

export function getConnection(id: string): ConnectionConfig | undefined {
  return connections.find(c => c.id === id);
}
