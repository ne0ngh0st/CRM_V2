import { Request, Response, NextFunction } from 'express';
import { appConfig } from '../config';
import { ApiError } from '../utils/errors';

export function auth(req: Request, _res: Response, next: NextFunction) {
  if (!appConfig.apiToken) return next(new ApiError(500, 'API_TOKEN_NOT_CONFIGURED', 'API_TOKEN não configurado no servidor'));
  const header = req.header('authorization') || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : '';
  if (token !== appConfig.apiToken) return next(new ApiError(401, 'UNAUTHORIZED', 'Token inválido ou ausente'));
  next();
}
