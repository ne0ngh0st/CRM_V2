import cors from 'cors';
import { appConfig } from '../config';

function matchesOrigin(origin: string, allowed: string): boolean {
  if (allowed.includes('*')) {
    const regex = new RegExp('^' + allowed.replace(/[.+?^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*') + '$');
    return regex.test(origin);
  }
  return origin === allowed;
}

export const corsMiddleware = cors({
  origin(origin, callback) {
    if (!origin) return callback(null, true);
    const ok = appConfig.allowedOrigins.length === 0 || appConfig.allowedOrigins.some(a => matchesOrigin(origin, a));
    callback(ok ? null : new Error('Origem não permitida pelo CORS'), ok);
  }
});
