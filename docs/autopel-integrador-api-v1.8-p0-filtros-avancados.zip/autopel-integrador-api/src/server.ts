import express from 'express';
import helmet from 'helmet';
import compression from 'compression';
import pinoHttp from 'pino-http';
import swaggerUi from 'swagger-ui-express';
import { v4 as uuidv4 } from 'uuid';
import { appConfig } from './config';
import { auth } from './middleware/auth';
import { corsMiddleware } from './middleware/security';
import { errorHandler } from './middleware/error';
import { healthRouter } from './routes/health';
import { metadataRouter } from './routes/metadata';
import { sampleRouter } from './routes/sample';
import { operacionalRouter } from './routes/operacional';
import { openApiSpec } from './openapi';
import { closePools } from './services/db';

const app = express();
app.use(helmet());
app.use(corsMiddleware);
app.use(compression());
app.use(express.json({ limit: '1mb' }));
app.use(pinoHttp({ genReqId: () => uuidv4() }));

app.use(healthRouter);
app.use('/docs', swaggerUi.serve, swaggerUi.setup(openApiSpec));
app.use(auth);
app.use(metadataRouter);
app.use(sampleRouter);
app.use(operacionalRouter);
app.use(errorHandler);

const server = app.listen(appConfig.port, () => {
  console.log(`Autopel Integrador API rodando na porta ${appConfig.port}`);
});

async function shutdown() {
  console.log('Encerrando API...');
  server.close(async () => {
    await closePools();
    process.exit(0);
  });
}
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);
