# Autopel Integrador API

API HTTP **somente leitura** para o Lovable consultar metadados e amostras limitadas dos bancos AWS RDS 1 PostgreSQL e múltiplos MySQL.

## Arquitetura

Lovable → API Integradora → AWS RDS PostgreSQL/MySQL

O Lovable não acessa os bancos diretamente. As credenciais ficam somente no ambiente da API.

## Endpoints

- `GET /health`
- `GET /metadata/connections`
- `GET /metadata/tables`
- `GET /metadata/tables/:id/columns`
- `GET /metadata/relationships`
- `GET /sample/:connection/:schema/:table?limit=10`
- `GET /docs` Swagger UI

Todas as rotas, exceto `/health`, exigem:

```http
Authorization: Bearer <API_TOKEN>
```

## Execução local

```bash
cp .env.example .env
npm install
npm run dev
```

## Docker

```bash
docker compose up --build
```

## Build

```bash
npm run build
npm start
```

## Segurança

- Usuários de banco devem ter apenas `SELECT`.
- A API executa apenas consultas de metadados e `SELECT` limitado para amostras.
- `/sample` é limitado por padrão a 10 registros.
- Identificadores de conexão/schema/tabela são validados contra metadados antes da consulta.
- Senhas nunca são retornadas nos endpoints.

## Deploy AWS sugerido

- AWS App Runner ou ECS/Fargate.
- RDS em subnet privada.
- API com acesso ao RDS por Security Group.
- Secrets no AWS Secrets Manager e injetados como variáveis de ambiente.
- CloudWatch Logs com retenção mínima de 90 dias.


## Configuração para 1 PostgreSQL + 3 MySQL

A versão 1.1.0 permite múltiplas conexões. Para o cenário atual, configure:

- `erp_pg` — banco PostgreSQL
- `mysql_erp` — primeiro banco MySQL
- `mysql_wms` — segundo banco MySQL
- `mysql_portal` — terceiro banco MySQL

A forma recomendada é usar a variável `CONNECTIONS_JSON` com um array de conexões. Exemplo completo está no arquivo `.env.example`.

Também é possível usar variáveis separadas:

- `PG_*` para o PostgreSQL
- `MYSQL_1_*`, `MYSQL_2_*`, `MYSQL_3_*` para os três bancos MySQL

Todos os usuários devem ser exclusivamente read-only.

## Versão 1.3.0 — Endpoints Operacionais de Pedidos

Esta versão adiciona endpoints operacionais somente leitura para o portal de acompanhamento de pedidos.

### Fonte principal

- Conexão: `sac` por padrão
- Schema: `sacautopel` por padrão
- Cabeçalho: `ConsultaBasePedidos`
- Itens: `ConsultaBaseNotasItens`

Esses valores podem ser alterados por variáveis de ambiente:

```env
OPERACIONAL_CONNECTION_ID=sac
OPERACIONAL_SCHEMA=sacautopel
OPERACIONAL_PEDIDOS_VIEW=ConsultaBasePedidos
OPERACIONAL_ITENS_VIEW=ConsultaBaseNotasItens
OPERACIONAL_DEFAULT_DATE_FIELD=previsao_entrega
OPERACIONAL_DEFAULT_LIMIT=100
OPERACIONAL_MAX_LIMIT=100
```

### Novos endpoints

Todos exigem `Authorization: Bearer <API_TOKEN>`.

#### `GET /operacional/pedidos`

Consulta a view `ConsultaBasePedidos`. A API não obriga período; filtros de data são opcionais.

Parâmetros opcionais:

- `data_inicio` no formato `YYYY-MM-DD`
- `data_fim` no formato `YYYY-MM-DD`

Observação: se uma data for enviada, a outra também deve ser enviada. A restrição de intervalo e obrigatoriedade fica na interface de consulta.

Demais parâmetros opcionais:

- `campo_data`: `previsao_entrega`, `data_bip`, `data_embarque`, `criado_em`, `atualizado_em`, `dt_emissao`, `emissao_nfe`, `data_entrega_desejada`, `previsao_faturamento`
- `pedido`
- `pedido_cliente`
- `nota_fiscal`
- `cliente`
- `cnpj`
- `status`
- `transportadora`
- `pagina`
- `limite`, máximo 100

Exemplo:

```bash
curl -H "Authorization: Bearer $API_TOKEN" \
  "https://api-integrador.autopel.com/operacional/pedidos?data_inicio=2026-06-01&data_fim=2026-06-15&campo_data=previsao_entrega&limite=50"
```

Regras de segurança:

- Não executa escrita.
- A API não impõe restrição de período; essa validação deve ser feita na interface de consulta.
- Pagina resultados.
- Usa apenas campos de data em whitelist.

#### `GET /operacional/pedidos/{pedido}`

Busca detalhes do pedido na view `ConsultaBasePedidos` comparando o valor informado com:

- `numero`
- `pedido_nfe`
- `ped_cliente`
- `nota_fiscal`
- `numero_nfe`

Exemplo:

```bash
curl -H "Authorization: Bearer $API_TOKEN" \
  "https://api-integrador.autopel.com/operacional/pedidos/946745"
```

#### `GET /operacional/pedidos/{pedido}/itens`

Busca itens na view `ConsultaBaseNotasItens` comparando o valor informado com:

- `pedido`
- `nota_fiscal`
- `nota_fiscal_nfe`
- `ped_cliente`

Parâmetros opcionais:

- `nota_fiscal`
- `filial`
- `limite`, máximo 500

Exemplo:

```bash
curl -H "Authorization: Bearer $API_TOKEN" \
  "https://api-integrador.autopel.com/operacional/pedidos/946745/itens"
```

#### `GET /operacional/pedidos/{pedido}/timeline`

Monta uma timeline simples a partir dos campos estruturais da view de pedidos, como `criado_em`, `dt_emissao`, `data_bip`, `data_embarque` e `previsao_entrega`.

### Chaves compostas retornadas

A resposta inclui chaves compostas úteis para relacionamento:

- `chave_pedido_sac = filial|numero`
- `chave_nf_sac = filial_nfe|nota_fiscal`
- `chave_pedido_item_sac = filial|pedido|item`
- `chave_nf_item_sac = filial_nfe|nota_fiscal|item`

### Observação

As rotas operacionais foram criadas para a primeira fase do portal, usando SAC como fonte principal. B2B e EASY seguem disponíveis nos endpoints de metadados e poderão ser adicionados aos endpoints operacionais em versões futuras.

## v1.4 — Correção de timeout em /operacional/pedidos

Esta versão otimiza os endpoints operacionais:

- `/operacional/pedidos` não executa `count(*)` por padrão.
- `include_total=false` por padrão.
- `limite` padrão 50; máximo 100.
- Não há join com itens na listagem.
- A busca por pedido/NF/CNPJ usa igualdade por padrão.
- Use `fuzzy=true` apenas para busca textual aproximada.
- Consulta sem data é permitida.
- Se informar data, envie obrigatoriamente `campo_data`, `data_inicio` e `data_fim`.
- Novo endpoint: `GET /operacional/metadata/campos-data`.

Exemplo:

```bash
curl -H "Authorization: Bearer $API_TOKEN" \
  'https://api-integrador.autopel.com/operacional/pedidos?pedido=946745&limite=50'
```

Com data:

```bash
curl -H "Authorization: Bearer $API_TOKEN" \
  'https://api-integrador.autopel.com/operacional/pedidos?campo_data=data_embarque&data_inicio=2026-06-01&data_fim=2026-06-30&limite=50'
```


## v1.5 - Correção de timeout em `/operacional/pedidos?pedido=...`

A busca por `pedido` não usa mais OR amplo em `numero`, `pedido_nfe`, `ped_cliente`, `nota_fiscal` e `numero_nfe` por padrão.
Agora `pedido=...` pesquisa somente em `numero`, reduzindo full scan em views grandes.

Para pesquisar em outro campo, use `campo_busca`:

```http
GET /operacional/pedidos?pedido=949066&campo_busca=numero
GET /operacional/pedidos?pedido=949066&campo_busca=pedido_nfe
GET /operacional/pedidos?pedido=949066&campo_busca=ped_cliente
GET /operacional/pedidos?pedido=949066&campo_busca=nota_fiscal
GET /operacional/pedidos?pedido=949066&campo_busca=numero_nfe
```

Também foram adicionados filtros dedicados:

```http
GET /operacional/pedidos?numero_pedido=949066
GET /operacional/pedidos?pedido_nfe=949066
GET /operacional/pedidos?pedido_cliente=OC123
GET /operacional/pedidos?nota_fiscal=123456
```

As datas continuam opcionais. Se houver data, a API exige `campo_data`, `data_inicio` e `data_fim`.


## Versão 1.6 - Busca operacional genérica

Adicionado endpoint genérico para evitar consultas amplas e permitir que a interface indique exatamente onde a busca deve ocorrer:

```http
GET /operacional/busca?connection=sac&schema=sacautopel&table=ConsultaBasePedidos&campo=numero&valor=949066
```

Regras:
- `connection`, `schema` e `table` são obrigatórios.
- Para buscar valor, enviar `campo` + `valor`.
- `campo` é validado contra os metadados da tabela/view.
- Se houver período, enviar `campo_data` + `data_inicio` + `data_fim`.
- Consulta sem data é permitida, sempre paginada.
- `limite` máximo: 100 registros.
- `operador`: `eq` padrão, `prefix` ou `like`.
- `fields` permite limitar as colunas retornadas.

Exemplos:

```http
GET /operacional/busca?connection=sac&schema=sacautopel&table=ConsultaBasePedidos&campo=numero&valor=949066&limite=10
GET /operacional/busca?connection=sac&schema=sacautopel&table=ConsultaBasePedidos&campo=nota_fiscal&valor=123456&fields=numero,nota_fiscal,cliente,status
GET /operacional/busca?connection=sac&schema=sacautopel&table=ConsultaBasePedidos&campo_data=data_embarque&data_inicio=2026-06-01&data_fim=2026-06-30&limite=50
```


## v1.7 - Consulta parametrizada com múltiplas linhas

Novo endpoint sem alterar `/operacional/busca`:

### GET /operacional/consulta

Permite consultar uma fonte específica e retornar múltiplas linhas dentro do período informado.

Parâmetros principais:

- `connection`: conexão/banco, ex.: `sac`
- `schema`: schema, ex.: `sacautopel`
- `table`: tabela ou view, ex.: `ConsultaBasePedidos`
- `campo_data`: campo de data que será usado no filtro, obrigatório somente quando houver data
- `data_inicio`: início do período, formato `YYYY-MM-DD`
- `data_fim`: fim do período, formato `YYYY-MM-DD`
- `campos` ou `fields`: lista de campos a retornar, separados por vírgula
- `campo` + `valor`: filtro simples opcional
- `filters`: JSON array de filtros opcionais
- `limite`: quantidade de linhas por página
- `pagina`: página

Exemplo:

```bash
curl -H "Authorization: Bearer $API_TOKEN" \
  "https://api-integrador.autopel.com/operacional/consulta?connection=sac&schema=sacautopel&table=ConsultaBasePedidos&campo_data=data_embarque&data_inicio=2026-06-01&data_fim=2026-06-30&campos=numero,cliente,nota_fiscal,transportadora,data_embarque,valor_total_pedido&limite=100"
```

### POST /operacional/consulta

Permite enviar `campos` e `filters` como arrays JSON. A API não aceita SQL livre; todos os campos, tabela e filtros são validados contra os metadados antes da montagem da query.

Exemplo de body:

```json
{
  "connection": "sac",
  "schema": "sacautopel",
  "table": "ConsultaBasePedidos",
  "campo_data": "data_embarque",
  "data_inicio": "2026-06-01",
  "data_fim": "2026-06-30",
  "campos": ["numero", "cliente", "nota_fiscal", "transportadora", "data_embarque"],
  "filters": [
    { "campo": "transportadora", "operador": "like", "valor": "JADLOG" }
  ],
  "limite": 100,
  "pagina": 1
}
```


## v1.8 - Filtros avançados, chaves compostas e campo_data flexível

Esta versão mantém os endpoints da v1.7 e adiciona melhorias P0 solicitadas pelo Lovable:

- `in` agora aceita até `OPERACIONAL_CONSULTA_IN_MAX` valores, padrão 1000.
- Novo operador `in_tuple` para chaves compostas, por exemplo `(filial, numero) IN (...)`.
- Novos operadores em `/operacional/consulta`: `between`, `ilike`, `is_null`, `not_null`, `not_in`.
- `campo_data` passa a ser semântico: pode apontar para colunas `date`, `datetime`, `timestamp`, `varchar`, `char` ou `text`.
- Para MySQL, campos de data em texto são convertidos na consulta quando estiverem em formatos comuns: `YYYY-MM-DD`, `YYYY-MM-DD HH:mm:ss`, `DD/MM/YYYY` ou `YYYYMMDD`.

Exemplo `in_tuple`:

```json
{
  "connection": "sac",
  "schema": "sacautopel",
  "table": "ConsultaBaseNotasItens",
  "campos": ["pedido", "item", "produto", "vlr_total"],
  "filters": [
    {
      "campo": ["filial", "pedido"],
      "operador": "in_tuple",
      "valores": [["01", "946745"], ["01", "946746"]]
    }
  ],
  "limite": 1000
}
```

Exemplo `campo_data` em `varchar`:

```http
GET /operacional/consulta?connection=sac&schema=sacautopel&table=ConsultaBasePedidos&campo_data=dt_emissao&data_inicio=2026-06-01&data_fim=2026-06-30&campos=numero,cliente,dt_emissao,nota_fiscal&limite=1000
```
