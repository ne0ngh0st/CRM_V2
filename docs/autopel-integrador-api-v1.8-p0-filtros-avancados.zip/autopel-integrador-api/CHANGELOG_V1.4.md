# Autopel Integrador API v1.4 — Correção de timeout operacional

## Objetivo
Resolver timeouts no endpoint `/operacional/pedidos` e ajustar a regra de datas conforme definido:

- Consulta sem data é permitida.
- Se houver data, é obrigatório informar `campo_data`, `data_inicio` e `data_fim`.
- A API não limita janela de datas; a restrição de período fica na interface Lovable.
- A API valida se `campo_data` é um dos campos permitidos.

## Principais correções

### 1. Performance da consulta operacional
- Remove `count(*)` obrigatório na listagem.
- `include_total=false` por padrão.
- Usa `LIMIT/OFFSET` sempre.
- Limite padrão reduzido para 50 e máximo 100.
- Listagem não faz join com itens.
- Busca itens apenas em `/operacional/pedidos/{pedido}/itens`.
- Seleciona somente colunas necessárias, não mais `select *`.
- Ordena por `id desc` quando não houver filtro de data.
- Quando houver data, ordena pelo próprio `campo_data`.
- Aplica filtros de pedido, NF e CNPJ com igualdade por padrão, para favorecer índices.
- `fuzzy=true` permite LIKE apenas quando necessário.

### 2. Regra de datas
- Sem data: permitido.
- Com data: exige o trio completo:
  - `campo_data`
  - `data_inicio`
  - `data_fim`
- Não usa `date(campo)` no WHERE, evitando invalidar índices.
- Usa:
  - `campo_data >= data_inicio`
  - `campo_data < DATE_ADD(data_fim, INTERVAL 1 DAY)`

### 3. Novo endpoint auxiliar

```http
GET /operacional/metadata/campos-data
```

Retorna os campos de data permitidos para montagem do combo no Lovable.

### 4. Timeout controlado
- Adicionado hint MySQL `MAX_EXECUTION_TIME` nas consultas SELECT operacionais.
- Configurável por:

```env
OPERACIONAL_QUERY_TIMEOUT_MS=12000
```

## Exemplos

Consulta aberta, paginada:

```http
GET /operacional/pedidos?pedido=946745&limite=50
```

Consulta com data:

```http
GET /operacional/pedidos?campo_data=data_embarque&data_inicio=2026-06-01&data_fim=2026-06-30&limite=50
```

Consulta com total, apenas quando necessário:

```http
GET /operacional/pedidos?campo_data=criado_em&data_inicio=2026-06-01&data_fim=2026-06-07&include_total=true
```

Busca textual mais ampla:

```http
GET /operacional/pedidos?cliente=prefeitura&fuzzy=true
```

## Observação
Se ainda houver 504 em consulta por pedido exato, o próximo passo técnico é criar índice no banco/view/tabela de origem ou criar uma view/materialização específica para consulta operacional.
