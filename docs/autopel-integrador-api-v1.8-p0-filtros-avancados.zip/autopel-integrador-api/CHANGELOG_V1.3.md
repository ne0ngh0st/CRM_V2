# API Integradora v1.3 — Ajuste de filtros de data

## Alteração principal

A API operacional não impõe mais obrigatoriedade de `data_inicio` e `data_fim` nem limite máximo de período.

A restrição de período passa a ser responsabilidade da interface de consulta, pois cada tabela/view pode possuir campos de data com finalidades diferentes.

## Comportamento atual

### `GET /operacional/pedidos`

- Pode ser chamado sem `data_inicio` e `data_fim`.
- Se `data_inicio` ou `data_fim` forem informados, ambos devem ser enviados juntos.
- Se período for informado, a API aplica o filtro usando `campo_data`.
- Se `campo_data` não for informado, usa `OPERACIONAL_DEFAULT_DATE_FIELD`.
- Não há validação de limite de dias na API.
- A paginação e o limite máximo continuam ativos.

### Exemplo sem data

```http
GET /operacional/pedidos?pedido=946745
```

### Exemplo com data

```http
GET /operacional/pedidos?campo_data=previsao_entrega&data_inicio=2026-06-01&data_fim=2026-06-15
```

## Campos de data permitidos

- `previsao_entrega`
- `data_bip`
- `data_embarque`
- `criado_em`
- `atualizado_em`
- `dt_emissao`
- `emissao_nfe`
- `data_entrega_desejada`
- `previsao_faturamento`

## Removido

- `OPERACIONAL_MAX_DAYS`
- Rejeição automática de consultas sem período
- Rejeição automática por período acima de 31 dias

