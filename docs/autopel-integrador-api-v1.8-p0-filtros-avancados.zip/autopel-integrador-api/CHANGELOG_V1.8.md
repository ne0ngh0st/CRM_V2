# v1.8 - Filtros avançados e campo_data flexível

## Objetivo
Resolver os gargalos P0 identificados pelo Lovable na consulta operacional de tabelas relacionadas grandes, sem alterar o comportamento dos endpoints existentes.

## Alterações principais

- `/operacional/consulta` agora suporta `in` com até 1000 valores por padrão.
- Novo operador `in_tuple` para chaves compostas, como `filial + pedido` ou `filial_nfe + nota_fiscal + item`.
- Novos operadores: `between`, `ilike`, `is_null`, `not_null`, `not_in`.
- `campo_data` passa a aceitar colunas `varchar`, `char` e `text` que contenham datas.
- Datas texto aceitas no MySQL: `YYYY-MM-DD`, `YYYY-MM-DD HH:mm:ss`, `DD/MM/YYYY`, `YYYYMMDD`.
- Novas variáveis:
  - `OPERACIONAL_CONSULTA_IN_MAX=1000`
  - `OPERACIONAL_CONSULTA_IN_TUPLE_MAX=1000`

## Compatibilidade

- Mantém `/operacional/busca` sem alteração funcional.
- Mantém `/operacional/consulta` GET/POST.
- Mantém as regras de validação de tabela e campo contra metadados.
- Não aceita SQL livre.
- Somente SELECT.
